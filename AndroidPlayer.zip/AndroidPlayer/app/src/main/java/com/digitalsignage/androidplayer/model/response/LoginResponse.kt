package com.digitalsignage.androidplayer.model.response

class LoginResponse {
}