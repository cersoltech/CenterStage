package com.digitalsignage.androidplayer.model.request

