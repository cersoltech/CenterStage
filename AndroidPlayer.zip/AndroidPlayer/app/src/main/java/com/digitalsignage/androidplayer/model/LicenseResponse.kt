package com.digitalsignage.androidplayer.model

data class LicenseResponse(
    val data: String,
    val message: String,
    val status: Boolean
)

