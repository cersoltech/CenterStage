package com.digitalsignage.androidplayer.model

data class TokenCounter(
        val tokenNumber: String? = null,
        val counterNumber: String? = null
){
    var isAnimate: Boolean = false
}